# Épico Fantasia — mod base para Minecraft Java 1.7.10

Este é um projeto-fonte inicial para um mod de fantasia épica usando Minecraft Forge 1.7.10.
Inclui um novo minério (Cristal Arcano), um item (Fragmento Arcano), uma espada (Lâmina Astral),
um bloco decorativo (Bloco de Cristal Arcano) e uma receita de fabricação.

## Importante
- Destino: Minecraft **Java Edition 1.7.10**.
- O projeto usa a estrutura clássica do ForgeGradle para Minecraft 1.7.10.
- A configuração antiga depende de ferramentas/repositórios legados e pode exigir ajustes no Java/Gradle
  atuais. Use um ambiente Java compatível com o ForgeGradle antigo (normalmente JDK 8).
- O ZIP contém o código-fonte, não um `.jar` compilado. Para compilar, siga os passos abaixo.

## Instalação no jogo
1. Faça backup dos seus mundos.
2. Instale o Minecraft Java 1.7.10 uma vez pelo launcher oficial.
3. Instale uma versão de Minecraft Forge para 1.7.10 compatível com sua instalação.
4. Compile o mod (passos abaixo).
5. Copie o `.jar` produzido em `build/libs/` para a pasta `.minecraft/mods/`.
6. Abra o perfil Forge 1.7.10 no launcher.

## Compilar o projeto
1. Instale o JDK 8.
2. Extraia o ZIP para uma pasta simples, por exemplo `C:\\Mods\\EpicoFantasia1710`.
3. Abra um terminal nessa pasta.
4. Execute `gradlew setupDecompWorkspace` e depois `gradlew build`.
   - Em algumas instalações antigas, o comando pode falhar por indisponibilidade de repositórios antigos.
   - Se isso acontecer, use uma distribuição/ambiente de desenvolvimento Forge 1.7.10 já configurado.
5. O arquivo compilado deve aparecer em `build/libs/`.

## Conteúdo incluído (v1.1.0)

### Minérios (e onde aparecem)
| Minério | Dropa | Dimensão / altura | Pico mínimo |
|---|---|---|---|
| Minério Arcano | 2-3 Fragmentos Arcanos | Overworld, Y 5-40 | Ferro |
| Minério de Mithril | ele mesmo (fundir -> Lingote de Mithril) | Overworld, Y 5-36 | Ferro |
| Minério de Safira Celeste | 1 Safira Celeste | Overworld, Y 5-30 | Ferro |
| Minério de Adamantita | ele mesmo (fundir -> Lingote de Adamantita) | Overworld, Y 1-14 (raro) | Diamante |
| Minério de Rubi Infernal | 1-2 Rubis Infernais | Nether, Y 10-110 | Diamante |

Fortuna funciona nos minérios que dropam gemas/fragmentos e eles soltam experiência.

### Ferramentas
Conjuntos completos (espada, picareta, machado, pá, enxada) de Mithril, Safira, Rubi e Adamantita,
mais picareta, machado, pá e enxada Arcanos. Receitas iguais às do jogo vanilla.

| Material | Nível | Durabilidade | Eficiência | Dano da espada |
|---|---|---|---|---|
| Arcano | 2 | 450 | 7.0 | 4.5 |
| Mithril | 3 | 900 | 8.5 | 5.0 |
| Safira | 3 | 1400 | 9.0 | 5.0 |
| Rubi | 3 | 1000 | 12.0 | 5.5 |
| Adamantita | 4 | 3000 | 10.0 | 7.0 |
| Astral (Lâmina Astral) | 3 | 2200 | 9.0 | 8.0 + lentidão |

(Ferro: 250 / 6.0 / 4.0 e Diamante: 1561 / 8.0 / 5.0 para comparação.)

### Blocos
Blocos de Cristal Arcano, Mithril, Safira, Rubi e Adamantita (9 itens <-> 1 bloco).

Tudo fica na aba criativa própria "Épico Fantasia".

Este é um ponto de partida para expandir com armaduras, criaturas, estruturas e dimensões.
