Texturas PNG 32x32 dos itens (todas já incluídas):
fragmento_arcano, lamina_astral, lingote_mithril, lingote_adamantita, gema_safira, gema_rubi
espada/picareta/machado/pa/enxada + _mithril, _safira, _rubi, _adamantita
picareta/machado/pa/enxada + _arcano
