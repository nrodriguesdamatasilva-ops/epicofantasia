Texturas PNG 32x32 dos blocos (todas já incluídas):
minerio_arcano, minerio_mithril, minerio_safira, minerio_rubi, minerio_adamantita
bloco_cristal_arcano, bloco_mithril, bloco_safira, bloco_rubi, bloco_adamantita
