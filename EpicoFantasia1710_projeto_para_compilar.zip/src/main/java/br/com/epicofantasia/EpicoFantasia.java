package br.com.epicofantasia;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraftforge.common.util.EnumHelper;

@Mod(modid = EpicoFantasia.MODID, name = EpicoFantasia.NAME, version = EpicoFantasia.VERSION)
public class EpicoFantasia {
    public static final String MODID = "epicofantasia";
    public static final String NAME = "Épico Fantasia";
    public static final String VERSION = "1.1.0";

    // Índices dos conjuntos de ferramentas
    private static final int SWORD = 0, PICK = 1, AXE = 2, SHOVEL = 3, HOE = 4;

    // ---- Materiais de ferramenta ----
    public static ToolMaterial MAT_ARCANO, MAT_MITHRIL, MAT_SAFIRA, MAT_RUBI, MAT_ADAMANTITA, MAT_ASTRAL;

    // ---- Itens ----
    public static Item fragmentoArcano, lingoteMithril, gemaSafira, gemaRubi, lingoteAdamantita;
    public static Item laminaAstral;
    public static Item[] ferramentasArcano, ferramentasMithril, ferramentasSafira,
            ferramentasRubi, ferramentasAdamantita;

    // ---- Blocos ----
    public static Block blocoCristalArcano, blocoMithril, blocoSafira, blocoRubi, blocoAdamantita;
    public static Block minerioArcano, minerioMithril, minerioSafira, minerioRubi, minerioAdamantita;

    // ---- Aba do criativo ----
    public static final CreativeTabs tab = new CreativeTabs("epicofantasia") {
        @Override
        @SideOnly(Side.CLIENT)
        public Item getTabIconItem() {
            return laminaAstral;
        }
    };

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // harvestLevel, durabilidade, eficiência, dano, encantabilidade
        MAT_ARCANO     = EnumHelper.addToolMaterial("ARCANO",     2,  450,  7.0F, 2.5F, 20);
        MAT_MITHRIL    = EnumHelper.addToolMaterial("MITHRIL",    3,  900,  8.5F, 3.0F, 18);
        MAT_SAFIRA     = EnumHelper.addToolMaterial("SAFIRA",     3, 1400,  9.0F, 3.0F, 15);
        MAT_RUBI       = EnumHelper.addToolMaterial("RUBI",       3, 1000, 12.0F, 3.5F, 22);
        MAT_ADAMANTITA = EnumHelper.addToolMaterial("ADAMANTITA", 4, 3000, 10.0F, 5.0F, 12);
        MAT_ASTRAL     = EnumHelper.addToolMaterial("ASTRAL",     3, 2200,  9.0F, 4.0F, 25);

        // ---- Itens ----
        fragmentoArcano   = registerItem("fragmentoArcano",   "fragmento_arcano");
        lingoteMithril    = registerItem("lingoteMithril",    "lingote_mithril");
        gemaSafira        = registerItem("gemaSafira",        "gema_safira");
        gemaRubi          = registerItem("gemaRubi",          "gema_rubi");
        lingoteAdamantita = registerItem("lingoteAdamantita", "lingote_adamantita");

        // Material de reparo de cada ferramenta
        MAT_ARCANO.customCraftingMaterial     = fragmentoArcano;
        MAT_MITHRIL.customCraftingMaterial    = lingoteMithril;
        MAT_SAFIRA.customCraftingMaterial     = gemaSafira;
        MAT_RUBI.customCraftingMaterial       = gemaRubi;
        MAT_ADAMANTITA.customCraftingMaterial = lingoteAdamantita;
        MAT_ASTRAL.customCraftingMaterial     = fragmentoArcano;

        laminaAstral = new ItemSwordAstral(MAT_ASTRAL)
                .setUnlocalizedName("laminaAstral")
                .setTextureName(MODID + ":lamina_astral")
                .setCreativeTab(tab);
        GameRegistry.registerItem(laminaAstral, "lamina_astral");

        // ---- Ferramentas ----
        ferramentasArcano     = registerToolSet("arcano",     MAT_ARCANO,     false);
        ferramentasMithril    = registerToolSet("mithril",    MAT_MITHRIL,    true);
        ferramentasSafira     = registerToolSet("safira",     MAT_SAFIRA,     true);
        ferramentasRubi       = registerToolSet("rubi",       MAT_RUBI,       true);
        ferramentasAdamantita = registerToolSet("adamantita", MAT_ADAMANTITA, true);

        // ---- Blocos de minério (nível de picareta: 2 = ferro, 3 = diamante) ----
        minerioArcano     = registerOre("minerioArcano",     "minerio_arcano",
                new BlockEpicoOre(fragmentoArcano, 2, 3, 1, 4), 3.0F, 2);
        minerioMithril    = registerOre("minerioMithril",    "minerio_mithril",
                new BlockEpicoOre(null, 1, 1, 0, 0), 3.5F, 2);
        minerioSafira     = registerOre("minerioSafira",     "minerio_safira",
                new BlockEpicoOre(gemaSafira, 1, 1, 3, 7), 3.5F, 2);
        minerioRubi       = registerOre("minerioRubi",       "minerio_rubi",
                new BlockEpicoOre(gemaRubi, 1, 2, 3, 7), 3.0F, 3);
        minerioAdamantita = registerOre("minerioAdamantita", "minerio_adamantita",
                new BlockEpicoOre(null, 1, 1, 0, 0), 6.0F, 3);

        // ---- Blocos de construção ----
        blocoCristalArcano = new Block(Material.glass)
                .setBlockName("blocoCristalArcano")
                .setBlockTextureName(MODID + ":bloco_cristal_arcano")
                .setHardness(1.5F)
                .setResistance(8.0F)
                .setStepSound(Block.soundTypeGlass)
                .setCreativeTab(tab);
        GameRegistry.registerBlock(blocoCristalArcano, "bloco_cristal_arcano");

        blocoMithril    = registerStorage("blocoMithril",    "bloco_mithril",    5.0F, 30.0F, 2);
        blocoSafira     = registerStorage("blocoSafira",     "bloco_safira",     5.0F, 30.0F, 2);
        blocoRubi       = registerStorage("blocoRubi",       "bloco_rubi",       5.0F, 30.0F, 2);
        blocoAdamantita = registerStorage("blocoAdamantita", "bloco_adamantita", 8.0F, 60.0F, 3);
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        // ---- Fundição ----
        GameRegistry.addSmelting(minerioMithril,    new ItemStack(lingoteMithril),    0.9F);
        GameRegistry.addSmelting(minerioAdamantita, new ItemStack(lingoteAdamantita), 1.5F);

        // ---- Blocos de armazenamento (9 itens <-> 1 bloco) ----
        addStorageRecipes(blocoCristalArcano, fragmentoArcano);
        addStorageRecipes(blocoMithril,       lingoteMithril);
        addStorageRecipes(blocoSafira,        gemaSafira);
        addStorageRecipes(blocoRubi,          gemaRubi);
        addStorageRecipes(blocoAdamantita,    lingoteAdamantita);

        // ---- Lâmina Astral (receita original mantida) ----
        GameRegistry.addRecipe(new ItemStack(laminaAstral),
                " C ", " C ", " P ",
                'C', fragmentoArcano, 'P', Items.stick);

        // ---- Ferramentas ----
        addToolRecipes(ferramentasArcano,     fragmentoArcano);
        addToolRecipes(ferramentasMithril,    lingoteMithril);
        addToolRecipes(ferramentasSafira,     gemaSafira);
        addToolRecipes(ferramentasRubi,       gemaRubi);
        addToolRecipes(ferramentasAdamantita, lingoteAdamantita);

        // ---- Geração de minérios no mundo ----
        WorldGenEpico gen = new WorldGenEpico();
        //        bloco             dim  alvo               tam tent  yMin yMax chance
        gen.add(minerioArcano,      0,  Blocks.stone,       6,  3,    5,  40,  1);
        gen.add(minerioMithril,     0,  Blocks.stone,       6,  4,    5,  36,  1);
        gen.add(minerioSafira,      0,  Blocks.stone,       5,  2,    5,  30,  1);
        gen.add(minerioAdamantita,  0,  Blocks.stone,       4,  1,    1,  14,  3);
        gen.add(minerioRubi,       -1,  Blocks.netherrack,  4,  8,   10, 110,  1);
        GameRegistry.registerWorldGenerator(gen, 3);
    }

    // ================= Ajudantes =================

    private static Item registerItem(String unlocalizedName, String registryName) {
        Item item = new Item()
                .setUnlocalizedName(unlocalizedName)
                .setTextureName(MODID + ":" + registryName)
                .setCreativeTab(tab);
        GameRegistry.registerItem(item, registryName);
        return item;
    }

    private static Block registerOre(String unlocalizedName, String registryName,
                                     Block block, float hardness, int harvestLevel) {
        block.setBlockName(unlocalizedName)
                .setBlockTextureName(MODID + ":" + registryName)
                .setHardness(hardness)
                .setResistance(5.0F)
                .setStepSound(Block.soundTypePiston)
                .setCreativeTab(tab);
        block.setHarvestLevel("pickaxe", harvestLevel);
        GameRegistry.registerBlock(block, registryName);
        return block;
    }

    private static Block registerStorage(String unlocalizedName, String registryName,
                                         float hardness, float resistance, int harvestLevel) {
        Block block = new Block(Material.iron)
                .setBlockName(unlocalizedName)
                .setBlockTextureName(MODID + ":" + registryName)
                .setHardness(hardness)
                .setResistance(resistance)
                .setStepSound(Block.soundTypeMetal)
                .setCreativeTab(tab);
        block.setHarvestLevel("pickaxe", harvestLevel);
        GameRegistry.registerBlock(block, registryName);
        return block;
    }

    /** Cria espada (opcional), picareta, machado, pá e enxada de um material. */
    private static Item[] registerToolSet(String id, ToolMaterial mat, boolean withSword) {
        String cap = Character.toUpperCase(id.charAt(0)) + id.substring(1);
        String[] kinds = {"espada", "picareta", "machado", "pa", "enxada"};
        Item[] set = new Item[5];
        if (withSword) set[SWORD] = new ItemSword(mat);
        set[PICK]   = new ItemPickaxe(mat);
        set[AXE]    = new ItemAxe(mat);
        set[SHOVEL] = new ItemSpade(mat);
        set[HOE]    = new ItemHoe(mat);
        for (int i = 0; i < set.length; i++) {
            if (set[i] == null) continue;
            set[i].setUnlocalizedName(kinds[i] + cap)
                  .setTextureName(MODID + ":" + kinds[i] + "_" + id)
                  .setCreativeTab(tab);
            GameRegistry.registerItem(set[i], kinds[i] + "_" + id);
        }
        return set;
    }

    private static void addToolRecipes(Item[] s, Item m) {
        if (s[SWORD] != null)
            GameRegistry.addRecipe(new ItemStack(s[SWORD]), " M ", " M ", " S ", 'M', m, 'S', Items.stick);
        GameRegistry.addRecipe(new ItemStack(s[PICK]),   "MMM", " S ", " S ", 'M', m, 'S', Items.stick);
        GameRegistry.addRecipe(new ItemStack(s[AXE]),    "MM ", "MS ", " S ", 'M', m, 'S', Items.stick);
        GameRegistry.addRecipe(new ItemStack(s[SHOVEL]), " M ", " S ", " S ", 'M', m, 'S', Items.stick);
        GameRegistry.addRecipe(new ItemStack(s[HOE]),    "MM ", " S ", " S ", 'M', m, 'S', Items.stick);
    }

    private static void addStorageRecipes(Block block, Item item) {
        GameRegistry.addRecipe(new ItemStack(block), "MMM", "MMM", "MMM", 'M', item);
        GameRegistry.addShapelessRecipe(new ItemStack(item, 9), block);
    }
}
