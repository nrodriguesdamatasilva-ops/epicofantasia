package br.com.epicofantasia;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

/**
 * Minério genérico do Épico Fantasia.
 * - drop == null: o minério dropa ele mesmo (deve ser fundido na fornalha).
 * - drop != null: dropa de min a max itens, com bônus de Fortuna e experiência.
 */
public class BlockEpicoOre extends Block {
    private final Item drop;
    private final int min, max, xpMin, xpMax;

    public BlockEpicoOre(Item drop, int min, int max, int xpMin, int xpMax) {
        super(Material.rock);
        this.drop = drop;
        this.min = min;
        this.max = max;
        this.xpMin = xpMin;
        this.xpMax = xpMax;
    }

    @Override
    public Item getItemDropped(int metadata, Random random, int fortune) {
        return drop != null ? drop : Item.getItemFromBlock(this);
    }

    @Override
    public int quantityDropped(Random random) {
        return min >= max ? min : min + random.nextInt(max - min + 1);
    }

    @Override
    public int quantityDroppedWithBonus(int fortune, Random random) {
        if (drop != null && fortune > 0) {
            int bonus = random.nextInt(fortune + 2) - 1;
            if (bonus < 0) bonus = 0;
            return quantityDropped(random) * (bonus + 1);
        }
        return quantityDropped(random);
    }

    @Override
    public int getExpDrop(IBlockAccess world, int metadata, int fortune) {
        if (drop == null || xpMax <= 0) return 0;
        Random rand = world instanceof World ? ((World) world).rand : new Random();
        return MathHelper.getRandomIntegerInRange(rand, xpMin, xpMax);
    }
}
