package br.com.epicofantasia;

import cpw.mods.fml.common.IWorldGenerator;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.feature.WorldGenMinable;

/** Gera todos os minérios do mod. Cada minério tem sua própria regra de raridade. */
public class WorldGenEpico implements IWorldGenerator {

    private static class Spec {
        Block block, target;
        int dimension, size, tries, minY, maxY, chance;
    }

    private final List<Spec> specs = new ArrayList<Spec>();

    /**
     * @param dimension 0 = Overworld, -1 = Nether
     * @param size      tamanho do veio
     * @param tries     tentativas por chunk
     * @param chance    1 = todo chunk; 3 = em média 1 a cada 3 chunks
     */
    public void add(Block block, int dimension, Block target, int size, int tries,
                    int minY, int maxY, int chance) {
        Spec s = new Spec();
        s.block = block; s.dimension = dimension; s.target = target;
        s.size = size; s.tries = tries; s.minY = minY; s.maxY = maxY; s.chance = chance;
        specs.add(s);
    }

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world,
                         IChunkProvider chunkGenerator, IChunkProvider chunkProvider) {
        for (Spec s : specs) {
            if (world.provider.dimensionId != s.dimension) continue;
            if (s.chance > 1 && random.nextInt(s.chance) != 0) continue;
            WorldGenMinable gen = new WorldGenMinable(s.block, s.size, s.target);
            for (int i = 0; i < s.tries; i++) {
                int x = chunkX * 16 + random.nextInt(16);
                int y = s.minY + random.nextInt(s.maxY - s.minY + 1);
                int z = chunkZ * 16 + random.nextInt(16);
                gen.generate(world, random, x, y, z);
            }
        }
    }
}
